<?php 
require_once "triangulo.php";
/**
* Implementacao da clase prisma triangular
*/
class PrismaTriangular extends Triangulo
{
	private $h;	

	function __construct(float $a, float $b, float $c,float $h)
	{
		parent::__construct($a, $b, $c, "Prisma Triangular");
		$this->h = $h;
	}

	/**
	 * retorna o calculo do volume do prisma
	 *
	 * @return     float  The volume.
	 */
	public function getVolume():float{
		return $volume = parent::area() * $this->h;
	}

	/**
	 * Calcula a area do prisma com base nos calculos da area feita no pai.
	 *
	 * @return     <float>  area do prisma
	 */
	public function area():float{
		return $area= (2* parent::area()) + (parent::getLadoA() * $this->h) + (parent::getLadoB() * $this->h) + (parent::getLadoC() * $this->h);
	}
}
 ?>