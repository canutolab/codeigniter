<?php 
interface interfaceDesenha{
	public function toSVG():string;
	public function toCanvas():string;
	
}


 ?>