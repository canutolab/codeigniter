<?php 
require_once "circulo.php";
/**
* 
*/
class Cilindro extends Circulo
{
	private $h;
	function __construct($h, $x, $y, $raio)
	{
		parent::__construct($raio, $x, $y, "Cilindro");
		$this->h = $h;
	}

	/**
	 * Implementacao do calculo do volume do cilindro fazendo uso do getRaio do
	 * pai pois o raio é um atributo privado
	 *
	 * @return     float  The volume.
	 */
	public function getVolume(): float{
		return $volume = parent::area() * $this->h;
	}

	/**
	 * Implmentacao do calculo da area do cilindro, este metodo chama-se area
	 * com a finalidade de fazer uma sobrecarga do metodo do pai chamado igual
	 *
	 * @return     float area do cilindro
	 */
	public function area(): float{

		return $area = 2 * pi() * parent::getRaio() * ($this->h + parent::getRaio()) ;
	}

	public function inRange(float $x, float $y, float $z):bool{
		return $retVal =((parent::emRango($x,$y) && ($z <= $this->h) && ($z >= 0)) ? true : false) ;
			
	}
}
 ?>