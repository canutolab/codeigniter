<?php 
require_once 'figurageometrica.php';
require_once "interfaceDesenha.php";
/**
* Clase circulo
*/
class Circulo extends FiguraGeometrica implements interfaceDesenha
{

	private $raio;
	private $x;
	private $y;


	
	public function __construct(float $raio = 1, float $x=0, float $y=0, string $nome="Circulo")
	{	
		/*condicao redundante*/
		if (!is_numeric($raio) || !is_numeric($x) || !is_numeric($y)) {
			throw new Exception("O radio deve ser um valor numerico");
		}
		parent::__construct($nome);
		$this->raio = $raio;
		$this->x = $x;
		$this->y = $y;
	}

	/**
	 * retorna o raio do circulo
	 *
	 * @return     number  radio do circulo
	 */
	public function raio():float{
		return $this->raio;
	}

	/**
	 * retorna a area do circulo
	 *
	 * @return     number  area do circulo
	 */
	public function area():float{
		$area = pi() * pow($this->raio, 2);
		return $area;
	}

	/**
	 * retorna o diametro do circulo
	 *
	 * @return     number  diametro
	 */
	public function diametro():float{
		$diametro = 2 * $this->raio;
		return $diametro;
	}

	/**
	 * Perimetro do circulo (2 x π x r)
	 *
	 * @return     boolean|integer  perimetro do circulo
	 */
	public function perimetro():float{
		$perimetro = 2 * pi() * $this->raio;
		return $perimetro;
	}

	/**
	 * Dados um par de coordenadas (x,y) que expressam a posicao de um ponto a
	 * funcao emRango devolve true se o ponto se encontra dentro da area do
	 * circulo e false se nao se encontrar
	 *
	 * @param      float  $x      coordenada do ponto no eixo dos x
	 * @param      float  $y      coordenada do ponto no eixo dos y
	 *
	 * @return     bool   se o ponto se encontra ou nao dentro do circulo
	 */
	public function emRango(float $x, float $y):bool{
		$distancia = static::distancia($x, $y, $this->x, $this->y);

		if ($distancia > $this->raio) {
			return false;
		}else{
			return true;
		}
	}
	
	/**
	 * dados dois pontos indicados pelos pares de coordenadas (x1,y1) e (x2,y2)
	 * a funcao distancia devolve a distancia entre eles. este metodo e
	 * estatico.
	 *
	 * @param      integer  $x1     coordenada do ponto 1 no eixo dos x
	 * @param      integer  $y1     coordenada do ponto 1 no eixo dos y
	 * @param      integer  $x2     coordenada do ponto 2 no eixo dos x
	 * @param      integer  $y2     coordenada do ponto 2 no eixo dos y
	 *
	 * @return     float    a distancia entre os dois pontos
	 */
	private static function distancia($x1, $y1, $x2, $y2):float{
		$distancia = (pow(($x2-$x1),2) + pow(($y2-$y1),2));
		$distancia = sqrt($distancia);
		return $distancia;
	}

    /**
     * Gets the value of raio.
     *
     * @return mixed
     */
    protected function getRaio()
    {
    	return $this->raio;
    }

    /**
     * Gets the value of raio.
     *
     * @return mixed
     */
    protected function getX()
    {
    	return $this->x;
    }

    /**
     * Gets the value of raio.
     *
     * @return mixed
     */
    protected function getY()
    {
    	return $this->y;
    }

    public function toSVG():string{
    	ob_start();
    	$factor =30;
    	$novoRaio = $this->raio *$factor;
    	$novoX = $this->x *$factor;
    	$novoY = $this->y *$factor;
    	echo "<svg width='100%' height='100%'>";
    	// linea dos y:
    	echo "<line x1='0%' y1='50%' x2='100%' y2='50%' style='stroke:#bbb;stroke-width:1'/>";
    	// linea dos x:
    	echo "<line x1='50%' y1='0%' x2='50%' y2='100%' style='stroke:#bbb;stroke-width:1'/>";
    	// circulo:
    	echo "<circle cx='50%' cy='50%' r='{$novoRaio}' fill='rgba(255,255,255,0)' stroke='#2196F3' stroke-width='3'/>";
    	// labels:
    	echo "<text x='75%' y='70%'>Raio: {$this->raio}</text>";
    	echo "<text x='75%' y='80%'>Diametro: {$this->diametro()}</text>";

    	//mensagem de erro caso nao suportar SVG:
    	echo "Sorry, your browser does not support inline SVG.";
    	echo "</svg>";
    	$saida = ob_get_clean();
    	return $saida;
    }

    public function toCanvas():string{
    	$factor =30;
    	$novoRaio = $this->raio *$factor;
    	$novoX = $this->x *$factor;
    	$novoY = $this->y *$factor;
    	
    	$width=533;
    	$height=$this->diametro()*$factor*1.1; // a altura do canvas vai ser a altura do circulo (vezes o seu fator) + 10% dessa altura
    	
    	$xcentro = $width/2;
    	$ycentro = $height/2;

    	ob_start(); //novo buffer
    	?>
    	<canvas id="myCanvas" width="<?php echo $wid ?>" minheight="150" class="img-responsive">
    		Your browser does not support the HTML5 canvas tag.
    	</canvas>
    	<script>
    		var c = document.getElementById("myCanvas");
    		var ctx = c.getContext("2d");

    		c.width = <?php echo $width ?>;
    		c.height = <?php echo $height ?>;

    		ctx.beginPath();
    		ctx.arc(<?php echo $xcentro ?>, <?php echo 	$ycentro ?>, <?php echo $novoRaio ?>, 0, 2*Math.PI);// ctx.arc(x, y, r, 0, 2*Math.PI);
    		ctx.strokeStyle="#2196F3";

    		ctx.fillText("Raio: <?php echo $this->raio() ?>",<?php echo ($xcentro + ($novoRaio/2)) ?>,<?php echo $ycentro ?>);
    		ctx.moveTo(<?php echo $xcentro ?>,<?php echo $ycentro ?>);
    		ctx.lineTo(<?php echo $xcentro+$novoRaio  ?>,(<?php echo $ycentro?>));

    		ctx.fillText("Diametro: <?php echo 	$this->diametro() ?>",<?php echo $xcentro - ($novoRaio)?>,<?php echo  ($ycentro + ($novoRaio/2)) ?>);
    		ctx.moveTo(<?php echo $xcentro?>,<?php echo ($ycentro -$novoRaio) ?>);
    		ctx.lineTo(<?php echo $xcentro  ?>,(<?php echo ($ycentro + $novoRaio)?>));


    		ctx.stroke();


    	</script> 
    	<?php
    	$saida = ob_get_clean();
    	return $saida;
    }
}
?>