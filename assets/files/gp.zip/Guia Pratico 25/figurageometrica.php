<?php 

/**
* 
*/
abstract class FiguraGeometrica
{
	protected $name;

	abstract function area():float;
	abstract function perimetro():float;

	public function __construct(string $nome){
		$this->name = $nome;
	}

    /**
     * Gets the value of name.
     *
     * @return mixed
     */
    public function nome()
    {
        return $this->name;
    }
}
 ?>