<?php 
require_once "cilindro.php";

class CilindroTest extends PHPUNIT_FRAMEWORK_TestCase
{
	public function testVolume1(){
		$cilindro = new Cilindro(4,0,0,2);
		$this->assertEquals($cilindro->getVolume(),50.265482457437);
	}

	public function testVolume2(){
		$cilindro = new Cilindro(4,0,0,2);
		$this->assertEquals($cilindro->getVolume(),30);
	}
}

 ?>
